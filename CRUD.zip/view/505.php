<?php

require_once './index.php';

?>

<div class="jumbotron">
  <h1 class="display-4">Ошибка 505</h1>
  <p class="lead">По вашему адресу нечего не найдено :(</p>
  <hr class="my-4">
  <p>Использются служебные классы для типографики и расстояния содержимого в контейнере большего размера.</p>
  <p class="lead">
    <a class="btn btn-primary btn-lg" href="/index" role="button">Главная страница</a>
  </p>
</div>