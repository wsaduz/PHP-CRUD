<style>

.btn-edit {
    position: absolute !important;
    right: 50px;
    border: 1px solid gray;
    border-radius: 2px;
    padding: 1px;
}

.btn-delete {
    position: absolute !important;
    right: 80px;

}

</style>