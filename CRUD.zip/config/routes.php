<?php

return [
    '/news/' => 'news',
    '/list/' => 'news',
    '/index/' => 'crud',
    '/create/' => 'create',
    '/edit/' => 'edit',
    '/delete/' => 'delete'
]

?>